import { useState } from 'react';
import AppLayout from './components/Applayout'; // O la ruta donde lo hayas puesto
import LoginPage from './pages/Loginpage';
import DashboardPage from "./pages/Dashboardpage";
import MateriasPage from "./pages/Materiaspage";
import CriteriosPage from "./pages/Criteriospage";
import GruposPage from "./pages/Grupospage";
import AlumnosPage from "./pages/Alumnospage";
import EquiposPage from "./pages/Equipospage";
import ExposicionesPage from "./pages/Exposicionespage";

import { getUsuario, clearSession } from './api/Client';

export default function App() {
  const [usuario, setUsuario] = useState(getUsuario());
  const [page, setPage] = useState('dashboard');

  const handleLogout = () => {
    clearSession();
    setUsuario(null);
  };

  // Si no hay usuario, mostramos SOLO el login
  if (!usuario) {
    return <LoginPage onLogin={(user) => setUsuario(user)} />;
  }

  // Función para inyectar el contenido dinámico
  const renderContent = () => {
    switch (page) {
      case "dashboard":
        return <DashboardPage />;
      case "materias":
        return <MateriasPage />;
      case "criterios":
        return <CriteriosPage />;
      case "grupos":
        return <GruposPage />;
      case "alumnos":
        return <AlumnosPage />;
      case "equipos":
        return <EquiposPage />;
      case "exposiciones":
        return <ExposicionesPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <AppLayout
      page={page}
      setPage={setPage}
      usuario={usuario}
      onLogout={handleLogout}
    >
      {renderContent()}
    </AppLayout>
  );
}